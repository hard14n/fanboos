import 'dart:convert';

class FollowUp {
  String username;
  String tglupdate;
  String keterangan;

  FollowUp({
    required this.username,
    required this.tglupdate,
    required this.keterangan,
  });

  factory FollowUp.fromJson(Map<String, dynamic> parsedJson) {
    return FollowUp(
      username: parsedJson['username'],
      tglupdate: parsedJson['tglupdate'],
      keterangan: parsedJson['keterangan'],
    );
  }

  static List<FollowUp> listFromJson(List<dynamic> list) {
    List<FollowUp> rows = list.map((i) => FollowUp.fromJson(i)).toList();
    return rows;
  }

  static List<FollowUp> listFromString(String responseBody) {
    final parsed = json.decode(responseBody).cast<Map<String, dynamic>>();
    return parsed.map<FollowUp>((json) => FollowUp.fromJson(json)).toList();
  }

  Map<String, dynamic> toJson() => {
        'username': username,
        'tglupdate': tglupdate,
        'keterangan': keterangan,
      };
}
