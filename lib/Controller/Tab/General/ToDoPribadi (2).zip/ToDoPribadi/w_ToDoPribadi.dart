import 'dart:ui';
import 'package:e_fansys/pages/widgets/w_general/ToDoPribadi/Model/toDoListModel.dart';
import 'package:e_fansys/pages/widgets/w_general/ToDoPribadi/toDoListDetail.dart';
import 'package:e_fansys/systems/constants.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
// import 'package:get/get.dart' hide Response;

List<TodoList> dtArray = [];
bool loading = false;
int count = 0;

class WidgetToDoListPribadi extends StatefulWidget {
  @override
  _WidgetToDoListPribadiState createState() => _WidgetToDoListPribadiState();
}

class _WidgetToDoListPribadiState extends State<WidgetToDoListPribadi>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    dtArray.clear();
    count = 0;
    loading = false;

    namaFormSebelumnya = '';
  }

  void getdataFromAPIwDIO() async {
    String _url = alamaturl + "/w_todolist_pribadi";
    Dio _dio = Dio();
    Response response;

    try {
      response = await _dio.get(_url,
          options: Options(headers: {"Authorization": "Bearer $mytoken"}));

      if (response.statusCode == invalidTokenStatusCode) {
        // login ulang
        setState(() {
          loading = false;
          count = 0;
        });
      } else {
        if (response.data['respon'] == 1) {
          dtArray.clear();

          dtArray = TodoList.listFromJson(response.data['data']);

          setState(() {
            loading = true;
            count = 1;
          });
        } else {
          //
          setState(() {
            loading = false;
            count = 0;
          });
        }
      }
    } on DioError catch (dioError) {
      print(dioError.response!.data);
    } on Exception catch (_) {
      print("throwing new error");
      throw Exception("Error on server");
    }
  }

  Widget build(BuildContext context) {
    // ignore: unused_local_variable
    var hScreen = MediaQuery.of(context).size.height;
    // ignore: unused_local_variable
    var wScreen = MediaQuery.of(context).size.width;

    print('To Do List Pribadi. Loading ' +
        loading.toString() +
        ' Jumlah data >> ' +
        dtArray.length.toString() +
        ' Count >> ' +
        count.toString() +
        ' Category Asset >> ');

    print('Nama Form >> ' + namaFormSebelumnya);

    if (dtArray.length == 0 && count == 0) {
      setState(() {
        getdataFromAPIwDIO();
      });
    }

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(5),
      child: Column(
        children: [
          Container(
            height: 30,
            alignment: Alignment.centerLeft,
            child: Text(
              'Todo List Pribadi',
              style: TextStyle(
                  fontSize: 15,
                  color: kPrimaryColor,
                  fontWeight: FontWeight.bold),
            ),
          ),
          dtArray.length == 0 && count == 0
              ? CircularProgressIndicator()
              : Container(
                  height: hScreen * 0.51,
                  width: wScreen * 0.98,
                  // color: Colors.grey[50],
                  // margin: EdgeInsets.all(2),
                  child: ListView(
                    children: dtArray
                        .map(
                          (e) => Container(
                            child: listData(context, e),
                          ),
                        )
                        .toList(),
                  ),
                ),
        ],
      ),
    );
  }

  String getNamaBulan(int mon) {
    String bulan = '';
    List months = [
      'jan',
      'feb',
      'mar',
      'apr',
      'may',
      'jun',
      'jul',
      'aug',
      'sep',
      'oct',
      'nov',
      'dec'
    ];

    bulan = months[mon];

    // print(bulan);

    return bulan;
  }

  InkWell listData(BuildContext context, TodoList e) {
    DateTime dueDate = DateTime.parse(e.due_date);
    String duedateNamaBulan = getNamaBulan(dueDate.month);
    return InkWell(
      onTap: () {
        namaFormSebelumnya = 'ToDoListDetail';

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ToDoListDetail(
              idLaporan: e.id_laporan_detail,
              topik: e.deskripsi_topik,
              uraianTopik: e.uraian_tindakan,
              followUp: e.follow_up,
              pic: username,
            ),
          ),
        );
        // print('From Detail >> ' + statusfromdetail.toString());
      },
      child: Container(
        height: 50,
        margin: const EdgeInsets.fromLTRB(2.0, 2.0, 2.0, 2.0),
        decoration: BoxDecoration(
          color: Colors.grey[50],
          border: Border(
            bottom: BorderSide(
                color: Colors.grey, width: 1, style: BorderStyle.solid),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 25,
              // color: Colors.blue[50],
              width: double.infinity,
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.only(left: 5),
                    width: MediaQuery.of(context).size.width * 0.87,
                    // color: Colors.blue,
                    child: new SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Text(
                        e.deskripsi_topik,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  Spacer(),
                  Container(
                    height: 15,
                    width: 15,
                    alignment: Alignment.center,
                    // color: Colors.amber[200],
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          spreadRadius: 1,
                          color: Colors.grey,
                          blurRadius: 3.0,
                        ),
                      ],
                    ),
                    child: Text(e.follow_up),
                  ),
                  SizedBox(width: 5),
                ],
              ),
            ),
            Container(
              // height: 54,
              width: double.infinity,
              // color: Colors.grey[50],
              margin: const EdgeInsets.only(left: 5),
              child: new SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Row(
                    children: [
                      Container(
                        width: 85,
                        alignment: Alignment.centerLeft,
                        child: Row(
                          children: [
                            Icon(
                              Icons.watch_later_outlined,
                              size: 17,
                            ),
                            Text(
                              ' Due.' +
                                  dueDate.day.toString() +
                                  ' ' +
                                  duedateNamaBulan,
                              style: TextStyle(
                                  color: getColors(e.due_date),
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
          ],
        ),
      ),
    );
  }

  Color getColors(String dueDate) {
    Color barColor;

    DateTime parsedDate = DateTime.parse(dueDate);
    DateTime now = DateTime.now();
    DateTime yesterday = DateTime(now.year, now.month, now.day - 6);

    barColor = Colors.black;

    if (parsedDate.isAfter(now)) {
      barColor = Colors.blue;
    } else {
      if (parsedDate.isAfter(yesterday) && parsedDate.isBefore(now)) {
        barColor = Colors.yellow;
      } else {
        if (parsedDate.isBefore(yesterday)) {
          barColor = Colors.red;
        }
      }
    }
    return barColor;
  }
}
