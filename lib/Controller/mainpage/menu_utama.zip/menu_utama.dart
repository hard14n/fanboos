import 'package:e_fansys/pages/LoginPages/login_page.dart';
import 'package:e_fansys/pages/mainpage/drawerEndScreen.dart';
import 'package:e_fansys/pages/mainpage/drawerScreen.dart';
import 'package:e_fansys/systems/constants.dart';
import 'package:e_fansys/systems/no_internet.dart';
import 'package:e_fansys/tab/tabGeneral.dart';
import 'package:e_fansys/tab/tabIT.dart';
import 'package:e_fansys/tab/tabSales.dart';
import 'package:flutter/material.dart';
import 'package:e_fansys/systems/connectivity_provider.dart';
import 'package:provider/provider.dart';

class MenuUtama extends StatefulWidget {
  MenuUtama({
    required this.username,
    required this.alamat,
    required this.title,
    required this.departemen,
    required this.statuskaryawan,
    required this.email,
  });

  final String username, alamat, title, departemen, statuskaryawan, email;

  @override
  _MenuUtamaState createState() => _MenuUtamaState();
}

class _MenuUtamaState extends State<MenuUtama> {
  late String token;

  int _selectorIndex = 0;
  // ignore: unused_field
  List<Widget> _widgetOption = [
    Text('Message'),
    Text('Home'),
    Text('Alert'),
  ];

  void _onItemTab(int index) {
    setState(() {
      _selectorIndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
    _selectorIndex = 1;
    Provider.of<ConnectivityProvider>(context, listen: false).startMonitoring();
  }

  Widget build(BuildContext context) {
    // Size size = MediaQuery.of(context).size;
    var mediaQueryData = MediaQuery.of(context);
    // ignore: unused_local_variable
    var hScreen = mediaQueryData.size.height;
    // ignore: unused_local_variable
    var wScreen = mediaQueryData.size.width;
    return Consumer<ConnectivityProvider>(
      builder: (context, model, child) {
        // ignore: unnecessary_null_comparison
        if (model.isOnline != null) {
          return model.isOnline
              ? MaterialApp(
                  debugShowCheckedModeBanner: false,
                  home: TabController(context, hScreen, wScreen),
                  routes: <String, WidgetBuilder>{
                      '/menu_utama': (BuildContext context) => new MenuUtama(
                            username: username,
                            alamat: alamat,
                            title: title,
                            departemen: departemen,
                            statuskaryawan: statuskaryawan,
                            email: email,
                          ),
                      '/loginpage': (BuildContext context) => new LoginPage(),
                    })
              : NoInternet();
        }
        return Container(
          child: Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );
  }

  // ignore: non_constant_identifier_names
  DefaultTabController TabController(context, hScreen, wScreen) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        // bottomNavigationBar: ButtomNavigator(),
        drawer: DrawerScreen(),
        endDrawer: DrawerEndScreen(),
        appBar: AppBar(
          centerTitle: true,
          title: Text(companyName),
          backgroundColor: kPrimaryColor,
          bottom: TabBar(
            isScrollable: true,
            unselectedLabelColor: Colors.white.withOpacity(0.3),
            indicatorColor: Colors.white,
            tabs: <Widget>[
              Container(width: 80, child: Tab(text: 'Umum')),
              Container(width: 80, child: Tab(text: 'Sales')),
              Container(width: 80, child: Tab(text: 'IT')),
              // Tab(text: 'Corp'),
              // Tab(text: 'Mkt'),
              // Tab(text: 'Fin'),
              // Tab(text: 'HRD'),
              // Tab(text: 'Prd'),
              // Tab(text: 'Rnd'),
              // Tab(text: 'QA'),
              // Tab(text: 'MM'),
            ],
          ),
          actions: [
            Builder(builder: (context) {
              return IconButton(
                icon: Icon(Icons.people),
                onPressed: () => Scaffold.of(context).openEndDrawer(),
              );
            }),
          ],
        ),
        body: TabBarView(
          children: <Widget>[
            TabGeneral(),
            TabSales(),
            TabIT(),
            // Center(child: Text("Corporate")),
            // Center(child: Text("Marketing")),
            // Center(child: Text("Finance")),
            // Center(child: Text("HRD")),
            // Center(child: Text("Produksi")),
            // Center(child: Text("RND")),
            // Center(child: Text("QA")),
            // Center(child: Text("MM")),
          ],
        ),
        bottomNavigationBar: Container(
          color: Colors.black54,
          child: DefaultTabController(
            length: 3,
            child: BottomNavigationBar(
              currentIndex: _selectorIndex,
              onTap: _onItemTab,
              backgroundColor: kPrimaryColor,
              selectedItemColor: Colors.white,
              unselectedItemColor: Colors.black54,
              items: [
                BottomNavigationBarItem(
                    icon: Icon(Icons.email_outlined),
                    // ignore: deprecated_member_use
                    title: Text('Message'),
                    backgroundColor: Colors.blue),
                BottomNavigationBarItem(
                    icon: Icon(Icons.home_max_outlined),
                    // ignore: deprecated_member_use
                    title: Text('Home'),
                    backgroundColor: Colors.blue),
                BottomNavigationBarItem(
                    icon: Icon(Icons.alarm_add_outlined),
                    // ignore: deprecated_member_use
                    title: Text('Alert'),
                    backgroundColor: Colors.blue),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Container colorsMethod() {
    return Container(
      height: 10,
      color: Colors.white,
    );
  }
}
